<?php 
 
return [
 
    /*
    |--------------------------------------------------------------------------
    | Home Page Language Lines
    |--------------------------------------------------------------------------
    |
    */
    'home' => 'Beranda',
    'about-us' => 'Tentang Kami',
    'vacancy' => 'Lowongan',
    'faq' => 'FAQ',
    'switch_language' => 'ID',
    'home2' => 'BERANDA',
    'about-us2' => 'TENTANG KAMI',
    'vacancy2' => 'LOWONGAN',
    'faq2' => 'FAQ',

    'search-1' => 'Pilih Negara',
    'search-2' => 'Pilih Departemen',
    'search-3' => 'Pilih Level',
    'search-btn' => 'Cari',

    'apply-now' => 'Lamar Sekarang',
    'see-details' => 'Lihat Selengkapnya',
];