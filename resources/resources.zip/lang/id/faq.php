<?php 
 
return [
 
    /*
    |--------------------------------------------------------------------------
    | Home Page Language Lines
    |--------------------------------------------------------------------------
    |
    */
    'home' => 'Beranda',
    'about-us' => 'Tentang Kami',
    'vacancy' => 'Lowongan',
    'faq' => 'FAQ',
    'switch_language' => 'ID',
    'home2' => 'BERANDA',
    'about-us2' => 'TENTANG KAMI',
    'vacancy2' => 'LOWONGAN',
    'faq2' => 'FAQ',
];