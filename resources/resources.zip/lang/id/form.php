<?php 
 
return [
 
    /*
    |--------------------------------------------------------------------------
    | Home Page Language Lines
    |--------------------------------------------------------------------------
    |
    */
    'home' => 'Beranda',
    'about-us' => 'Tentang Kami',
    'vacancy' => 'Lowongan',
    'faq' => 'FAQ',
    'switch_language' => 'ID',
    'home2' => 'BERANDA',
    'about-us2' => 'TENTANG KAMI',
    'vacancy2' => 'LOWONGAN',
    'faq2' => 'FAQ',

    
    'form' => 'FORMULIR LAMARAN',
    'apply' => 'Anda Melamar Dengan Posisi',
    'personal' => 'Data Pribadi',
    'education' => 'Data Pendidikan',
    'work' => 'Pengalaman Kerja',
    'skill' => 'Keterampilan Berbahasa',
    'apply-now' => 'LAMAR SEKARANG'
];