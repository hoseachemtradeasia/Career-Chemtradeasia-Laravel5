<?php 
 
return [
 
    /*
    |--------------------------------------------------------------------------
    | Home Page Language Lines
    |--------------------------------------------------------------------------
    |
    */
    'home' => 'Home',
    'about-us' => 'About Us',
    'vacancy' => 'Vacancy',
    'faq' => 'FAQ',
    'switch_language' => 'EN',
    'why-choose-us' => 'Why Choose Us?',
    'home2' => 'HOME',
    'about-us2' => 'ABOUT US',
    'vacancy2' => 'VACANCY',
    'faq2' => 'FAQ',
];